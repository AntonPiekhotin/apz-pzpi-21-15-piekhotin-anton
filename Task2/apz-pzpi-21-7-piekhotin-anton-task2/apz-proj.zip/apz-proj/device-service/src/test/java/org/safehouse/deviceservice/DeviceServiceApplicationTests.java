package org.safehouse.deviceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeviceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
