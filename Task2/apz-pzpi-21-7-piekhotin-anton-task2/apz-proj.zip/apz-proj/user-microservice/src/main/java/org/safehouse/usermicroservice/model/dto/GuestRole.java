package org.safehouse.usermicroservice.model.dto;

public enum GuestRole {
	ADMIN, CLIENT
}
