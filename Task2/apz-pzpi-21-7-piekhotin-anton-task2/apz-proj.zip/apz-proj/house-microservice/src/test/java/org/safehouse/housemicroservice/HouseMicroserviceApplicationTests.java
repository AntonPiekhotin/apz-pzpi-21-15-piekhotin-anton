package org.safehouse.housemicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HouseMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
