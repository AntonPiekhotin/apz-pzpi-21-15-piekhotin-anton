package org.safehouse.authservice.model.entity;

public enum GuestRole {
	ADMIN,
	CLIENT
}
